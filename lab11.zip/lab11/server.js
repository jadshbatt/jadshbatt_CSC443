var express = require('express');
var app = express();
var bodyParser = require('body-parser');
const ejs= require("ejs");
let webSocket= require("ws");

const url1 = require('url'); 
app.use(express.static(__dirname+"/public"));

let globalarray=[];
app.use( bodyParser.json() ); 
app.use(bodyParser.urlencoded({     
        extended: true
      })); 

app.use(function(req, res, next) {
        res.header("Access-Control-Allow-Origin", "*"); // update to match the domain you will make the request from
        res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
        next();
});


app.get("/",function(req,res){
    res.sendFile(__dirname+"/public/index.html");
})


app.post("/adduser",function(req,res){
    console.log("in post /adduser");
    let fname= req.body.fName;
    let lname=req.body.lName;
    let gender=req.body.gender;
    let desc=req.body.desc;

    let newObj={};
    newObj.fname=fname;
    newObj.lname=lname;
    newObj.gender=gender;
    newObj.desc=desc;

    globalarray.push(newObj);
})
app.get("/admin",function(req,res){
    res.sendFile(__dirname+"/public/admin.html");
});

var server = app.listen(8081, function () {
    var host = server.address().address
    var port = server.address().port
    console.log("listening on 8081");
 })

let ws= new webSocket.Server({port:8080});

ws.on("connection",function(thisWs){
    console.log("connected");
    globalarray.forEach((val)=>{
        thisWs.send(val.fname + " " +val.lname+" "+val.gender+" "+val.desc);
        
    })
           
    });


///// connect:id:username
///// disconx:id:username
///// p2p:user1:user2:msg
///// broadcast:user:msg