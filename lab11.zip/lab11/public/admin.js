let wsUrl= "ws://localhost:8080";
let connection= new WebSocket(wsUrl);

connection.onopen=function(){
    console.log("connected");
}


connection.onmessage=function(e){
    let newP= document.createElement("p")
    newP.innerText=e.data;
    let hr= document.createElement("hr")
    document.querySelector("#div_results").appendChild(newP);
    document.querySelector("#div_results").appendChild(hr);

}

