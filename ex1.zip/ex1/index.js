var resultArr= [];
  $("#ex1 #items li").each(function(){
      resultArr.push($(this).text());
  })
  let resultString= resultArr.join(", ");
  let newp= document.createElement("p");
  newp.innerText=resultString;
  $("#ex1 #result").append(newp);



  $("#ex1 #items li").hide();
  $("#ex1 #items li").show();

  $("#ex1 #items li.test").hide();


$("#ex1 #BlueBtn").on("click",function()
{
  $("#ex1 #items li").each(function(){
    if($(this).css("color")=="blue"){
      $(this).removeAttr('style');
    }else
    $(this).css('color','blue');
  });
  return;
});

$("#ex2 #changeBtn").on("click",function()
{
  const textVal =$("#ex2 #input_color").val()
  $("#ex2 .cow_color").each(function(){
    
   $("#ex2 .cow_color").replaceWith(textVal);
    
  })
});